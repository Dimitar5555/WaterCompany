Hello. Thank you for downloading Water Company 0.4.
note: 
 * This is recoded version of the game. Some features and tabs are not implemented.
To play the game, drag index.html file to your browser. Then you are ready to play. You can bookmark the page.
Also this version doesn't have a save system. Sorry for that.